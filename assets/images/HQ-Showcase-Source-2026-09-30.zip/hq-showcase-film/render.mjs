// Renders the film frame by frame into a lossless master.
//   node render.mjs                 → out/master-cinema.mkv (50 fps, camera drift on)
//   node render.mjs --gif           → out/master-gif.mkv    (25 fps, no drift: the README cut)
//   node render.mjs --from 27 --to 36   (a section, for review)
// Every frame is produced by setting the film clock, so nothing depends on how fast the machine is.
import fs from "node:fs";
import path from "node:path";
import { spawn } from "node:child_process";
import { build, preview } from "vite";
import { chromium } from "playwright-core";

const args = process.argv.slice(2);
const opt = (k, d) => (args.includes(k) ? args[args.indexOf(k) + 1] : d);
const GIF = args.includes("--gif");
const FPS = GIF ? 25 : 50;
const from = Number(opt("--from", 0));
const to = opt("--to");
const out = path.resolve(opt("--out", `out/master-${GIF ? "gif" : "cinema"}${to ? `-${from}-${to}` : ""}.mkv`));
fs.mkdirSync(path.dirname(out), { recursive: true });

await build({ logLevel: "error" });
const server = await preview({ preview: { port: 5198, strictPort: true }, logLevel: "error" });
const browser = await chromium.launch();
const page = await browser.newPage({ viewport: { width: 1920, height: 1080 }, deviceScaleFactor: 1 });
page.on("pageerror", (e) => {
  console.error("pageerror:", e.message);
  process.exitCode = 1;
});
await page.goto(`http://localhost:5198/${GIF ? "?gif" : ""}`);
await page.waitForFunction(() => window.__film);
const duration = await page.evaluate(async () => {
  await window.__film.ready;
  return window.__film.duration;
});
const end = to ? Number(to) : duration;
const frames = Math.round((end - from) * FPS);
const cdp = await page.context().newCDPSession(page);

const ff = spawn("ffmpeg", ["-hide_banner", "-loglevel", "error", "-y", "-f", "image2pipe", "-framerate", String(FPS), "-c:v", "png", "-i", "-", "-c:v", "libx264rgb", "-crf", "0", "-preset", "ultrafast", out], {
  stdio: ["pipe", "inherit", "inherit"],
});
const write = (buf) => new Promise((res) => (ff.stdin.write(buf) ? res() : ff.stdin.once("drain", res)));

const t0 = Date.now();
for (let f = 0; f < frames; f++) {
  const t = from + f / FPS;
  await page.evaluate((x) => window.__film.seek(x), t);
  const { data } = await cdp.send("Page.captureScreenshot", { format: "png", optimizeForSpeed: true });
  await write(Buffer.from(data, "base64"));
  if (f % 250 === 0) console.log(`frame ${f}/${frames} · t=${t.toFixed(2)}s · ${((Date.now() - t0) / 1000).toFixed(0)}s elapsed`);
}
ff.stdin.end();
await new Promise((res) => ff.on("close", res));
await browser.close();
await new Promise((res) => server.httpServer.close(res));
console.log(`wrote ${out}: ${frames} frames at ${FPS} fps in ${((Date.now() - t0) / 1000).toFixed(0)}s`);
