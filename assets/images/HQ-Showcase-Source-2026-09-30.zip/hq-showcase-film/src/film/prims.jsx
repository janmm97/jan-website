import { motion, useTransform } from "framer-motion";
import { useMemo } from "react";
import { time, CINEMA } from "./time";
import { clamp01, lerp, expoOut, cubicIn, hq, camera, typeTimes, springs } from "./ease";

const MONO = '"JetBrains Mono Variable", ui-monospace, monospace';
export const font = (weight, size, lh = 1.3) => `${weight} ${size}px/${lh} ${MONO}`;

/** A time window: outside it the subtree is hidden, so it costs no layout or paint. */
export function Scene({ from, to, children, style }) {
  const visibility = useTransform(time, (t) => (t >= from && t <= to ? "visible" : "hidden"));
  return <motion.div style={{ position: "absolute", inset: 0, visibility, ...style }}>{children}</motion.div>;
}

/** Enter at `at`, leave at `out`: fade, travel and de-blur, on HQ's ease-out-expo curve. */
export function Enter({ at, dur = 0.7, out, outDur = 0.45, y = 26, x = 0, scale = 1, blur: blurIn = 5, ease = hq, style, children, as = "div" }) {
  // The README cut skips entrance blur: soft, ever-changing edges are what an animated image stores worst.
  const blur = CINEMA ? blurIn : 0;
  const env =(t) => [ease(clamp01((t - at) / dur)), out == null ? 0 : cubicIn(clamp01((t - out) / outDur))];
  const opacity = useTransform(time, (t) => {
    const [a, b] = env(t);
    return a * (1 - b);
  });
  const ty = useTransform(time, (t) => {
    const [a, b] = env(t);
    return (1 - a) * y - b * y * 0.6;
  });
  const tx = useTransform(time, (t) => {
    const [a, b] = env(t);
    return (1 - a) * x - b * x * 0.6;
  });
  const sc = useTransform(time, (t) => lerp(scale, 1, env(t)[0]));
  const filter = useTransform(time, (t) => {
    const [a, b] = env(t);
    const v = (1 - a) * blur + b * blur * 0.8;
    return v > 0.04 ? `blur(${v.toFixed(2)}px)` : "none";
  });
  const M = motion[as];
  return <M style={{ ...style, opacity, y: ty, x: tx, scale: sc, filter }}>{children}</M>;
}

/** DESIGN.md's develop reveal: a grey, soft ghost at 12% that comes up to full contrast. */
export function Develop({ at, dur = 0.9, out, outDur = 0.45, blur = 9, children, style }) {
  const opacity = useTransform(time, (t) => {
    if (t < at) return 0;
    const p = clamp01((t - at) / dur);
    const o = p < 0.6 ? lerp(0.12, 0.85, p / 0.6) : lerp(0.85, 1, (p - 0.6) / 0.4);
    return o * (1 - (out == null ? 0 : cubicIn(clamp01((t - out) / outDur))));
  });
  const filter = useTransform(time, (t) => {
    const p = clamp01((t - at) / dur);
    const b = (1 - expoOut(p)) * blur;
    const c = lerp(0.45, 1, hq(p));
    return b < 0.04 && c > 0.999 ? "none" : `blur(${b.toFixed(2)}px) contrast(${c.toFixed(3)})`;
  });
  return <motion.div style={{ ...style, opacity, filter }}>{children}</motion.div>;
}

/** A slow push-in over a scene's life, so nothing on screen is ever quite still. */
export function Drift({ from, to, amount = 0.02, children, style }) {
  const k = CINEMA ? amount : 0;
  const scale = useTransform(time, (t) => 1 + k * camera(clamp01((t - from) / (to - from))));
  return <motion.div style={{ position: "absolute", inset: 0, scale, ...style }}>{children}</motion.div>;
}

/** Kinetic type: a line rises into view through its own mask, and leaves the same way. */
export function Line({ at, dur = 0.95, out, outDur = 0.5, children, style }) {
  const y = useTransform(time, (t) => {
    const a = hq(clamp01((t - at) / dur));
    const b = out == null ? 0 : cubicIn(clamp01((t - out) / outDur));
    return `${((1 - a) * 112 - b * 112).toFixed(3)}%`;
  });
  return (
    <div style={{ overflow: "hidden", paddingBottom: "0.14em", marginBottom: "-0.14em", ...style }}>
      <motion.div style={{ y }}>{children}</motion.div>
    </div>
  );
}

/** Typed text with the safelight caret; the rhythm is seeded, so every render types identically. */
export function Type({ text, at, cps = 26, seed = 7, caret = true, caretFrom, caretTo, style }) {
  const times = useMemo(() => typeTimes(text, at, cps, seed), [text, at, cps, seed]);
  const end = times[times.length - 1];
  const shown = useTransform(time, (t) => {
    let lo = 0;
    let hi = text.length;
    while (lo < hi) {
      const mid = (lo + hi) >> 1;
      if (times[mid] <= t) lo = mid + 1;
      else hi = mid;
    }
    return text.slice(0, lo);
  });
  const caretOpacity = useTransform(time, (t) => {
    if (caretFrom != null && t < caretFrom) return 0;
    if (caretTo != null && t > caretTo) return 0;
    if (t < end + 0.25) return 1;
    return Math.floor((t - end - 0.25) / 0.5) % 2 === 0 ? 0 : 1;
  });
  return (
    <span style={style}>
      <motion.span>{shown}</motion.span>
      {caret && (
        <motion.span
          style={{
            opacity: caretOpacity,
            display: "inline-block",
            width: "0.1em",
            height: "1.02em",
            background: "var(--safe)",
            verticalAlign: "-0.16em",
            marginLeft: "0.05em",
          }}
        />
      )}
    </span>
  );
}
export const typeEnd = (text, at, cps = 26, seed = 7) => typeTimes(text, at, cps, seed).at(-1);

/** A number that counts up on HQ's curve. */
export function Count({ at, dur = 1.4, from = 0, to, ease = expoOut, fmt = (v) => String(Math.round(v)), style }) {
  const v = useTransform(time, (t) => fmt(lerp(from, to, ease(clamp01((t - at) / dur)))));
  return <motion.span style={style}>{v}</motion.span>;
}

/** An Elapsed readout that ticks with the film clock. */
export function Elapsed({ base, at, style }) {
  const v = useTransform(time, (t) => {
    const s = Math.max(0, Math.floor(base + Math.max(0, t - at)));
    return `${String(Math.floor(s / 60)).padStart(2, "0")}:${String(s % 60).padStart(2, "0")}`;
  });
  return <motion.span style={style}>{v}</motion.span>;
}

const MARK = {
  you: { background: "var(--safe)", color: "var(--on-safe)", border: "2px solid var(--safe)" },
  fixed: { background: "var(--fixed)", color: "var(--ground)", border: "2px solid var(--fixed)" },
  running: { color: "var(--paper)", border: "2px solid var(--paper)" },
  plan: { color: "var(--silver-hi)", border: "2px solid var(--silver)" },
  line: { color: "var(--silver-hi)", border: "2px dashed var(--silver)" },
  unverified: { color: "var(--paper)", border: "2px dashed var(--paper)" },
  failed: { color: "var(--fog)", border: "2px solid var(--fog)", textDecoration: "line-through", textDecorationThickness: "2px" },
  pulled: { color: "var(--silver)", border: "2px solid var(--rim-strong)" },
};
/** HQ's state word in the state's shape: fill, outline, dash or strike. */
export function Mark({ tone = "plan", size = 1, children, style }) {
  return (
    <span
      style={{
        display: "inline-flex",
        alignItems: "center",
        height: 42 * size,
        padding: `0 ${14 * size}px`,
        borderRadius: 6,
        font: font(700, 19 * size, 1),
        letterSpacing: "0.12em",
        textTransform: "uppercase",
        whiteSpace: "nowrap",
        boxSizing: "border-box",
        ...MARK[tone],
        ...style,
      }}
    >
      {children}
    </span>
  );
}

export const panelStyle = {
  position: "absolute",
  background: "var(--room)",
  border: "2px solid var(--rim)",
  borderRadius: 12,
  // DESIGN.md's "surface rest" shadow. The README cut drops it: on the near-black ground it is barely
  // visible, but every moving panel would drag a dithered gradient through the GIF.
  boxShadow: CINEMA ? "0 32px 60px -44px rgba(0,0,0,0.95)" : "none",
  boxSizing: "border-box",
};

export function Label({ children, style }) {
  return (
    <div style={{ font: font(700, 20, 1.2), letterSpacing: "0.16em", textTransform: "uppercase", color: "var(--silver-hi)", ...style }}>
      {children}
    </div>
  );
}

/** The left column: station code and name, the title in kinetic type, then the explanation. */
export function Headline({ h, at, out }) {
  return (
    <div style={{ position: "absolute", left: 120, top: 262, width: 700 }}>
      <Enter at={at} out={out} dur={0.6} y={10} blur={0}>
        <div style={{ display: "flex", alignItems: "baseline", gap: 18, marginBottom: 30 }}>
          <span style={{ font: font(700, 24, 1), color: "var(--silver)" }}>{h.code}</span>
          <span style={{ font: font(800, 24, 1), letterSpacing: "0.18em", textTransform: "uppercase", color: "var(--silver-hi)" }}>{h.label}</span>
          <StationTick at={at} out={out} />
        </div>
      </Enter>
      {h.title.map((line, i) => (
        <Line
          key={i}
          at={at + 0.1 + i * 0.1}
          out={out != null ? out + i * 0.05 : undefined}
          style={{ font: font(700, 70, 1.08), letterSpacing: "-0.035em", color: "var(--paper)" }}
        >
          {line}
        </Line>
      ))}
      <Enter at={at + 0.42} out={out} dur={0.9} y={18} blur={5} style={{ marginTop: 38, font: font(400, 29, 1.5), color: "var(--silver)", maxWidth: 640 }}>
        {h.sub}
      </Enter>
    </div>
  );
}

/** A hairline that draws beside the station name. */
function StationTick({ at, out }) {
  const scaleX = useTransform(time, (t) => {
    const a = hq(clamp01((t - at - 0.1) / 0.9));
    const b = out == null ? 0 : cubicIn(clamp01((t - out) / 0.4));
    return a * (1 - b);
  });
  return <motion.span style={{ flex: "0 0 120px", height: 2, background: "var(--rim-strong)", alignSelf: "center", originX: 0, scaleX }} />;
}

/** The test strip as a thin bar: six stepped bands that print in from the left. */
export function StripBar({ left, top, width, height, at, stagger = 0.085, dur = 0.55 }) {
  const colors = ["var(--s1)", "var(--s2)", "var(--s3)", "var(--s4)", "var(--s5)", "var(--s6)"];
  return (
    <div style={{ position: "absolute", left, top, width, height, display: "flex", borderRadius: 3, overflow: "hidden" }}>
      {colors.map((c, i) => (
        <StripCell key={i} color={c} at={at + i * stagger} dur={dur} />
      ))}
    </div>
  );
}
function StripCell({ color, at, dur }) {
  const scaleX = useTransform(time, (t) => hq(clamp01((t - at) / dur)));
  return <motion.div style={{ flex: 1, background: color, originX: 0, scaleX }} />;
}

/** A settled outline chip: a route or mode, a scope line. */
export function Tag({ children, style }) {
  return (
    <span
      style={{
        display: "inline-flex",
        alignItems: "center",
        height: 44,
        padding: "0 16px",
        border: "2px solid var(--rim-strong)",
        borderRadius: 6,
        font: font(600, 16, 1),
        letterSpacing: "0.08em",
        textTransform: "uppercase",
        color: "var(--silver-hi)",
        whiteSpace: "nowrap",
        boxSizing: "border-box",
        ...style,
      }}
    >
      {children}
    </span>
  );
}

/**
 * A roll: the first thing until `at`, then it rolls up out of a mask as the second rolls in beneath it.
 * Both share one grid cell, so the box is as wide as the wider of the two and the pair never overlap.
 */
export function Roll({ at, a, b, anchor = "left", dur = 0.42, style }) {
  const p = (t) => hq(clamp01((t - at) / dur));
  const ya = useTransform(time, (t) => `${(-112 * p(t)).toFixed(3)}%`);
  const yb = useTransform(time, (t) => `${(112 * (1 - p(t))).toFixed(3)}%`);
  const align = anchor === "left" ? "start" : "end";
  return (
    <span style={{ display: "inline-grid", overflow: "hidden", verticalAlign: "middle", ...style }}>
      <motion.span style={{ gridArea: "1 / 1", justifySelf: align, alignSelf: "center", y: ya, display: "inline-flex", whiteSpace: "nowrap" }}>{a}</motion.span>
      <motion.span style={{ gridArea: "1 / 1", justifySelf: align, alignSelf: "center", y: yb, display: "inline-flex", whiteSpace: "nowrap" }}>{b}</motion.span>
    </span>
  );
}

/** Two state marks in one place, rolled from the first to the second at `at`. */
export function SwapMark({ at, a, b, size = 1, anchor = "right", style }) {
  return (
    <Roll
      at={at}
      anchor={anchor}
      style={style}
      a={
        <Mark tone={a[0]} size={size}>
          {a[1]}
        </Mark>
      }
      b={
        <Mark tone={b[0]} size={size}>
          {b[1]}
        </Mark>
      }
    />
  );
}

/** The six stepped bands, sweeping across the frame: HQ's signature, used as the scene cut. */
export function StripWipe({ at }) {
  const colors = ["var(--s1)", "var(--s2)", "var(--s3)", "var(--s4)", "var(--s5)", "var(--s6)"];
  return (
    <Scene from={at - 0.05} to={at + 1.5} style={{ zIndex: 50, pointerEvents: "none" }}>
      {colors.map((c, i) => (
        <WipeBand key={i} i={i} at={at} color={c} />
      ))}
    </Scene>
  );
}
function WipeBand({ i, at, color }) {
  const y = useTransform(time, (t) => {
    const a = expoOutInOut(clamp01((t - at - i * 0.05) / 0.5));
    const b = expoOutInOut(clamp01((t - at - 0.62 - i * 0.05) / 0.52));
    return `${((1 - a) * 101 - b * 101).toFixed(3)}%`;
  });
  return <motion.div style={{ position: "absolute", top: 0, bottom: 0, left: i * 320, width: 321, background: color, y }} />;
}
const expoOutInOut = (t) => (t <= 0 ? 0 : t >= 1 ? 1 : t < 0.5 ? Math.pow(2, 20 * t - 10) / 2 : (2 - Math.pow(2, -20 * t + 10)) / 2);

/** The operator's pointer: travels a cubic Bézier, and presses once. */
export function Cursor({ p, at, dur, pressAt, from, to }) {
  const pos = (t) => {
    const u = camera(clamp01((t - at) / dur));
    const m = 1 - u;
    const x = m * m * m * p[0][0] + 3 * m * m * u * p[1][0] + 3 * m * u * u * p[2][0] + u * u * u * p[3][0];
    const y = m * m * m * p[0][1] + 3 * m * m * u * p[1][1] + 3 * m * u * u * p[2][1] + u * u * u * p[3][1];
    // After the click the hand eases off the button, out of the way of what the click revealed.
    const off = hq(clamp01((t - pressAt - 0.2) / 0.6));
    return [x + 36 * off, y + 44 * off];
  };
  const x = useTransform(time, (t) => pos(t)[0]);
  const y = useTransform(time, (t) => pos(t)[1]);
  const scale = useTransform(time, (t) => {
    const d = t - pressAt;
    if (d < 0) return 1;
    if (d < 0.1) return lerp(1, 0.84, d / 0.1);
    return lerp(0.84, 1, springs.pop(d - 0.1));
  });
  const opacity = useTransform(time, (t) => clamp01((t - from) / 0.25) * (1 - clamp01((t - to) / 0.3)));
  return (
    <motion.svg width="46" height="46" viewBox="0 0 24 24" style={{ position: "absolute", left: 0, top: 0, x, y, scale, opacity, originX: 0.1, originY: 0.1, zIndex: 40, overflow: "visible" }}>
      <path d="M3 2 L3 19.5 L7.6 15.4 L10.6 22 L13.6 20.6 L10.7 14.2 L17 14.2 Z" fill="var(--paper)" stroke="var(--ground)" strokeWidth="1.3" strokeLinejoin="round" />
    </motion.svg>
  );
}

/** One "At a glance" circle: a 4px track, an arc drawn clockwise from twelve, a centre and a label. */
export function Ring({ at, value, of, label, tone = "var(--fixed)", size = 128 }) {
  const r = size / 2 - 7;
  const pathLength = useTransform(time, (t) => (of ? (value / of) * expoOut(clamp01((t - at) / 1.5)) : 0));
  const arcOpacity = useTransform(time, (t) => (t > at ? 1 : 0));
  return (
    <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 14 }}>
      <div style={{ position: "relative", width: size, height: size }}>
        <svg width={size} height={size} style={{ position: "absolute", inset: 0, transform: "rotate(-90deg)" }}>
          <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="var(--rim)" strokeWidth="6" />
          <motion.circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke={tone} strokeWidth="6" strokeLinecap="butt" style={{ pathLength, opacity: arcOpacity }} />
        </svg>
        <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center", font: font(200, 38, 1), color: "var(--paper)" }}>
          <Count at={at} dur={1.5} to={value} />
        </div>
      </div>
      <div style={{ font: font(700, 17, 1.2), letterSpacing: "0.16em", textTransform: "uppercase", color: "var(--silver-hi)" }}>{label}</div>
    </div>
  );
}
