// Cue sheet, in seconds. Scenes overlap by a few hundred milliseconds so exits and entrances cross.
export const T = {
  open: { from: 0, to: 5.45 },
  wipe1: 4.3,
  ask: { from: 4.85, to: 10.7, head: 5.25, headOut: 9.9, type: 6.15, send: 8.95 },
  route: { from: 9.0, to: 18.4, head: 10.4, headOut: 17.55 },
  plan: { from: 17.7, to: 27.6, head: 18.15, headOut: 26.75 },
  expose: { from: 26.9, to: 39.0, head: 27.35, headOut: 38.05, press: 34.25 },
  verify: { from: 38.3, to: 46.6, head: 38.75, headOut: 45.75 },
  scale: { from: 45.9, to: 54.5, head: 46.35 },
  wipe2: 53.6,
  end: { from: 54.05, to: 59 },
  chrome: { from: 4.6, to: 54.2, needsFrom: 29.95, needsTo: 34.55 },
  chapters: [5.0, 10.25, 18.05, 27.25, 38.65, 46.25],
  chaptersEnd: 53.7,
};
