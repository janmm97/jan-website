import { motion, useTransform } from "framer-motion";
import { time } from "../time";
import { T } from "../timeline";
import { C } from "../colors";
import { HEAD, PLAN_STREAM, PLAN_STEPS } from "../copy";
import { clamp01, lerp, hq, sineInOut, springs } from "../ease";
import { Scene, Drift, Headline, Enter, Label, Mark, panelStyle, font } from "../prims";

const P = T.plan;
const SCAN = [22.75, 24.45]; // HQ's check sweeps the plan, top to bottom
const ROW0 = 350;
const ROW_H = 86;
const rowCheck = (i) => SCAN[0] + (i / (PLAN_STEPS.length - 1)) * (SCAN[1] - SCAN[0]) + 0.08;

/** 03 Plan: a read-only planning session streams its lookups, then HQ checks every step. */
export function Plan() {
  return (
    <Scene from={P.from} to={P.to}>
      <Drift from={P.from} to={P.to} amount={0.014}>
      <Headline h={HEAD.plan} at={P.head} out={P.headOut} />
      <Enter at={18.45} out={P.headOut} dur={0.85} y={34} style={{ ...panelStyle, left: 900, top: 168, width: 900, height: 770 }}>
        <Label style={{ position: "absolute", left: 26, top: 30 }}>Planning session · One</Label>
        <div style={{ position: "absolute", right: 22, top: 18 }}>
          <Mark tone="plan" size={0.9}>
            Read-only
          </Mark>
        </div>
        <div style={{ position: "absolute", left: 0, right: 0, top: 78, height: 2, background: C.rim }} />
        {PLAN_STREAM.map(([cmd, res], i) => (
          <Enter key={cmd} at={19.0 + i * 0.42} dur={0.5} x={-14} y={0} blur={3} style={{ position: "absolute", left: 26, right: 26, top: 100 + i * 44, display: "flex", alignItems: "baseline", gap: 14 }}>
            <span style={{ font: font(700, 20, 1.2), color: C.silver }}>›</span>
            <span style={{ font: font(400, 20, 1.2), color: C.silverHi, flex: 1 }}>{cmd}</span>
            <span style={{ font: font(600, 17, 1.2), letterSpacing: "0.06em", color: C.silver }}>{res}</span>
          </Enter>
        ))}
        <div style={{ position: "absolute", left: 0, right: 0, top: 288, height: 2, background: C.rim }} />
        <Enter at={20.85} dur={0.5} y={8} blur={0} style={{ position: "absolute", left: 26, top: 310 }}>
          <Label>Plan · 4 steps</Label>
        </Enter>
        <Scanner />
        {PLAN_STEPS.map((s, i) => (
          <Step key={s.text} s={s} i={i} />
        ))}
        <Enter at={24.95} dur={0.7} y={12} style={{ position: "absolute", left: 26, right: 26, top: 706, font: font(400, 21, 1.3), color: C.silver }}>
          <b style={{ color: C.paper }}>4</b> steps · <b style={{ color: C.paper }}>2</b> reads · <b style={{ color: C.paper }}>2</b> writes{" "}
          <span style={{ color: C.paper }}>held for your approval</span>
        </Enter>
      </Enter>
      </Drift>
    </Scene>
  );
}

function Scanner() {
  const y = useTransform(time, (t) => lerp(ROW0, ROW0 + (PLAN_STEPS.length - 1) * ROW_H, sineInOut(clamp01((t - SCAN[0]) / (SCAN[1] - SCAN[0])))));
  const opacity = useTransform(time, (t) => hq(clamp01((t - SCAN[0] + 0.2) / 0.25)) * (1 - clamp01((t - SCAN[1] - 0.1) / 0.3)));
  return (
    <motion.div style={{ position: "absolute", left: 12, right: 12, top: 0, height: 76, y, opacity, borderRadius: 8, background: "rgba(242,242,242,0.045)" }}>
      <div style={{ position: "absolute", left: 0, top: 0, bottom: 0, width: 3, background: C.paper, borderRadius: 2 }} />
    </motion.div>
  );
}

function Step({ s, i }) {
  const at = 21.1 + i * 0.3;
  const check = rowCheck(i);
  const stamp = useTransform(time, (t) => hq(clamp01((t - check) / 0.35)));
  const stampX = useTransform(time, (t) => (1 - hq(clamp01((t - check) / 0.5))) * 16);
  const flagScale = useTransform(time, (t) => lerp(1.25, 1, springs.pop(t - check)));
  return (
    <Enter at={at} dur={0.6} y={14} blur={3} style={{ position: "absolute", left: 12, right: 12, top: ROW0 + i * ROW_H, height: 76 }}>
      <div style={{ position: "absolute", left: 16, top: 26, font: font(700, 20, 1), color: C.silver }}>{String(i + 1).padStart(2, "0")}</div>
      <div style={{ position: "absolute", left: 62, top: 21 }}>
        <Mark tone={s.kind === "WRITE" ? "running" : "plan"} size={0.8}>
          {s.kind}
        </Mark>
      </div>
      <div style={{ position: "absolute", left: 186, top: 25, font: font(400, 21, 1.2), color: C.paper }}>{s.text}</div>
      {s.check === "ok" ? (
        <motion.div style={{ position: "absolute", right: 16, top: 27, opacity: stamp, x: stampX, font: font(600, 17, 1.2), letterSpacing: "0.04em", color: C.silverHi }}>
          ✓ live&nbsp;&nbsp;&nbsp;✓ looked up
        </motion.div>
      ) : (
        <motion.div style={{ position: "absolute", right: 14, top: 19, opacity: stamp, scale: flagScale }}>
          <Mark tone="unverified" size={0.8}>
            Not looked up · flagged
          </Mark>
        </motion.div>
      )}
      {i < PLAN_STEPS.length - 1 && <div style={{ position: "absolute", left: 12, right: 12, bottom: -6, height: 2, background: C.rim }} />}
    </Enter>
  );
}
