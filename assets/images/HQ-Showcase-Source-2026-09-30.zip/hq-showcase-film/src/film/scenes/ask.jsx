import { motion, useTransform } from "framer-motion";
import { time } from "../time";
import { T } from "../timeline";
import { C } from "../colors";
import { HEAD, REQUEST } from "../copy";
import { clamp01, lerp, springs } from "../ease";
import { Scene, Headline, Enter, Type, Tag, panelStyle, font } from "../prims";

/** 01 Ask: the composer takes focus (its rim turns to the safelight) and the request is typed. */
export function Ask() {
  const a = T.ask;
  return (
    <Scene from={a.from} to={a.to}>
      <Headline h={HEAD.ask} at={a.head} out={a.headOut} />
      <Composer />
    </Scene>
  );
}

function Composer() {
  const a = T.ask;
  const rim = useTransform(time, [a.type - 0.4, a.type - 0.1, a.send + 0.02, a.send + 0.16, a.send + 0.5], [C.rim, C.safe, C.safe, C.paper, C.rim]);
  const placeholder = useTransform(time, (t) => (t < a.type ? 1 : 0));
  // The typed text hands over to the request card, which starts exactly on top of it.
  const textOpacity = useTransform(time, (t) => (t < a.send + 0.12 ? 1 : 0));
  const press = useTransform(time, (t) => {
    const d = t - a.send;
    if (d < 0) return 1;
    if (d < 0.08) return lerp(1, 0.86, d / 0.08);
    return lerp(0.86, 1, springs.pop(d - 0.08));
  });
  const btn = useTransform(time, [a.send - 0.01, a.send, a.send + 0.3], [C.safe, C.safeLit, C.safe]);
  return (
    <Enter at={5.55} dur={0.85} out={a.send + 0.45} outDur={0.45} y={44} blur={6} style={{ position: "absolute", left: 900, top: 392, width: 900 }}>
      <motion.div style={{ ...panelStyle, position: "relative", height: 330, borderColor: rim, boxShadow: "0 20px 50px -24px rgba(0,0,0,0.95)" }}>
        <motion.div style={{ position: "absolute", left: 36, top: 34, font: font(400, 38, 1.45), color: C.gray, opacity: placeholder }}>
          Give J/OS HQ a task…
        </motion.div>
        <motion.div style={{ position: "absolute", left: 36, top: 34, right: 36, opacity: textOpacity }}>
          <Type
            text={REQUEST}
            at={a.type}
            cps={30}
            seed={11}
            caretFrom={a.type - 0.4}
            caretTo={a.send + 0.1}
            style={{ font: font(400, 38, 1.45), color: C.paper, whiteSpace: "pre-wrap" }}
          />
        </motion.div>
        <div style={{ position: "absolute", left: 36, right: 30, bottom: 30, display: "flex", alignItems: "center", gap: 14 }}>
          <Tag>Route · auto</Tag>
          <Tag>Mode · edit automatically</Tag>
          <div style={{ flex: 1 }} />
          <span style={{ font: font(400, 17, 1), color: C.silver, marginRight: 6 }}>Enter to send</span>
          <motion.div
            style={{ width: 64, height: 64, borderRadius: 8, background: btn, scale: press, display: "flex", alignItems: "center", justifyContent: "center" }}
          >
            <svg width="30" height="30" viewBox="0 0 24 24">
              <path d="M12 19.5V5M5.5 11.5 12 5l6.5 6.5" stroke={C.ground} strokeWidth="2.6" fill="none" strokeLinecap="square" />
            </svg>
          </motion.div>
        </div>
      </motion.div>
    </Enter>
  );
}
