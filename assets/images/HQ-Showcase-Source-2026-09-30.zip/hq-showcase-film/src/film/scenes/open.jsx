import { motion, useTransform } from "framer-motion";
import { time, CINEMA } from "../time";
import { T } from "../timeline";
import { C } from "../colors";
import { TAGLINE } from "../copy";
import { clamp01, lerp, camera } from "../ease";
import { Scene, Line, Develop, StripBar, font } from "../prims";

/** Cold open: the light comes up, the test strip prints, and the wordmark develops in. */
export function Open() {
  const scale = useTransform(time, (t) => (CINEMA ? lerp(1.08, 1, camera(clamp01(t / 4.7))) : 1));
  return (
    <Scene from={T.open.from} to={T.open.to}>
      <motion.div style={{ position: "absolute", inset: 0, scale }}>
        <StripBar left={520} top={318} width={880} height={16} at={0.4} />
        <Develop
          at={1.15}
          dur={1.05}
          style={{ position: "absolute", left: 0, right: 0, top: 372, display: "flex", justifyContent: "center", alignItems: "baseline", gap: 28 }}
        >
          <span style={{ font: font(800, 196, 1), letterSpacing: "-0.045em", color: C.paper }}>J/OS</span>
          <span style={{ font: font(700, 56, 1), letterSpacing: "0.22em", color: C.silverHi }}>HQ</span>
        </Develop>
        <div style={{ position: "absolute", left: 0, right: 0, top: 650, textAlign: "center" }}>
          <Line at={2.0} style={{ font: font(300, 42, 1.3), color: C.silverHi }}>
            {TAGLINE[0]}
          </Line>
          <Line at={2.28} style={{ font: font(300, 42, 1.3), color: C.silverHi, marginTop: 12 }}>
            {TAGLINE[1][0]}
            <span style={{ color: C.safe, fontWeight: 500 }}>{TAGLINE[1][1]}</span>
          </Line>
        </div>
      </motion.div>
    </Scene>
  );
}
