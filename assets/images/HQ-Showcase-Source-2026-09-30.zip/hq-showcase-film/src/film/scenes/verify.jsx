import { motion, useTransform } from "framer-motion";
import { time } from "../time";
import { T } from "../timeline";
import { C } from "../colors";
import { HEAD, STATIONS, RESULT, LOG_LINES } from "../copy";
import { clamp01, lerp, hq, springs } from "../ease";
import { Scene, Drift, Headline, Enter, Develop, Label, Mark, panelStyle, font } from "../prims";

const V = T.verify;
const ST0 = 39.95;
const ST_STEP = 0.42;
const DEVELOP = 42.55;
const VERIFIED = 43.4;

/** 05 Verify: the task's six stations tone in, the result develops, and the log closes. */
export function Verify() {
  return (
    <Scene from={V.from} to={V.to}>
      <Drift from={V.from} to={V.to} amount={0.014}>
      <Headline h={HEAD.verify} at={V.head} out={V.headOut} />
      <Enter at={39.15} out={V.headOut} dur={0.8} y={30} style={{ ...panelStyle, left: 900, top: 168, width: 900, height: 196 }}>
        <Label style={{ position: "absolute", left: 26, top: 24 }}>Stations</Label>
        <div style={{ position: "absolute", left: 20, right: 20, top: 64, height: 112, display: "flex", borderRadius: 4, overflow: "hidden" }}>
          {STATIONS.map((s, i) => (
            <Station key={s.name} s={s} i={i} />
          ))}
        </div>
      </Enter>
      <ResultCard />
      <Enter at={43.7} out={V.headOut} dur={0.8} y={28} style={{ ...panelStyle, left: 900, top: 716, width: 900, height: 214 }}>
        <Label style={{ position: "absolute", left: 26, top: 24 }}>Log · written twice</Label>
        <div style={{ position: "absolute", right: 26, top: 25, font: font(400, 16, 1.2), color: C.silver }}>opened when routed · closed when verified</div>
        {LOG_LINES.map((line, i) => (
          <Enter key={line} at={44.0 + i * 0.22} dur={0.55} x={-12} y={0} blur={2} style={{ position: "absolute", left: 26, right: 26, top: 72 + i * 42 }}>
            <span style={{ font: font(i === 0 ? 700 : 400, 20, 1.2), color: i === 0 ? C.paper : C.silverHi }}>{line}</span>
          </Enter>
        ))}
      </Enter>
      </Drift>
    </Scene>
  );
}

/** A station: dashed until reached, ringed while current, then toned to its step of the strip. */
function Station({ s, i }) {
  const at = ST0 + i * ST_STEP;
  const done = at + 0.3;
  const tone = C.strip[i];
  const ink = i < 3 ? C.ground : C.silverHi;
  const sub = i < 2 ? "#3a3a3a" : i === 2 ? "#141414" : C.silver;
  const background = useTransform(time, [at - 0.01, at + 0.12, done, done + 0.3], [C.clear, C.tray, C.tray, tone]);
  const nameInk = useTransform(time, [at - 0.01, at + 0.12, done, done + 0.3], [C.gray, C.paper, C.paper, ink]);
  const roleInk = useTransform(time, [at - 0.01, at + 0.12, done, done + 0.3], [C.rimStrong, C.silverHi, C.silverHi, sub]);
  const ring = useTransform(time, (t) => clamp01((t - at) / 0.12) * (1 - clamp01((t - done) / 0.2)));
  const dash = useTransform(time, (t) => 1 - clamp01((t - at) / 0.15));
  return (
    <motion.div style={{ position: "relative", flex: 1, background }}>
      <motion.div style={{ position: "absolute", inset: 0, border: `2px dashed ${C.rimStrong}`, borderLeftWidth: i === 0 ? 2 : 0, opacity: dash }} />
      <motion.div style={{ position: "absolute", inset: 0, boxShadow: `inset 0 0 0 3px ${C.paper}`, opacity: ring }} />
      <motion.div style={{ position: "absolute", left: 14, top: 22, font: font(800, 16, 1.1), letterSpacing: "0.08em", textTransform: "uppercase", color: nameInk }}>{s.name}</motion.div>
      <motion.div style={{ position: "absolute", left: 14, top: 60, font: font(400, 15, 1.2), color: roleInk }}>{s.role}</motion.div>
    </motion.div>
  );
}

function ResultCard() {
  const mark = useTransform(time, (t) => clamp01((t - VERIFIED) / 0.15));
  const markScale = useTransform(time, (t) => lerp(1.4, 1, springs.pop(t - VERIFIED)));
  const out = useTransform(time, (t) => 1 - hq(clamp01((t - V.headOut) / 0.45)));
  const y = useTransform(time, (t) => -hq(clamp01((t - V.headOut) / 0.45)) * 16);
  return (
    <motion.div style={{ position: "absolute", left: 900, top: 392, width: 900, height: 300, opacity: out, y }}>
      <Develop at={DEVELOP} dur={0.9} style={{ ...panelStyle, inset: 0 }}>
        <div style={{ position: "absolute", left: 26, top: 28, font: font(700, 26, 1), color: C.paper }}>{RESULT.title}</div>
        <motion.div style={{ position: "absolute", right: 22, top: 18, opacity: mark, scale: markScale, originX: 1 }}>
          <Mark tone="fixed">Verified</Mark>
        </motion.div>
        <div style={{ position: "absolute", left: 0, right: 0, top: 84, height: 2, background: C.rim }} />
        {RESULT.rows.map(([k, v, check], i) => (
          <div key={k} style={{ position: "absolute", left: 26, right: 26, top: 106 + i * 62, display: "flex", alignItems: "baseline" }}>
            <span style={{ width: 130, font: font(600, 20, 1.2), color: C.silverHi }}>{k}</span>
            <span style={{ flex: 1, font: font(400, 21, 1.2), color: C.paper }}>{v}</span>
            <span style={{ font: font(600, 18, 1.2), letterSpacing: "0.04em", color: C.silverHi }}>✓ {check}</span>
          </div>
        ))}
        <div style={{ position: "absolute", left: 26, top: 244, font: font(400, 20, 1.2), color: C.silver }}>{RESULT.took}</div>
      </Develop>
    </motion.div>
  );
}
