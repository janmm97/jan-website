import { motion, useTransform } from "framer-motion";
import { time } from "../time";
import { T } from "../timeline";
import { C } from "../colors";
import { HEAD, PAYLOAD, GATEWAY } from "../copy";
import { clamp01, lerp, hq, expoOut, springs, cubicIn } from "../ease";
import { Scene, Drift, Headline, Enter, Develop, Mark, SwapMark, Roll, Cursor, panelStyle, font } from "../prims";

const E = T.expose;
const PRESS = E.press;
const HOVER = PRESS - 0.4;
const CARD = { left: 900, top: 256, width: 900, height: 676 };

/** 04 Expose: an unapproved write is refused; the exact payload waits; the operator approves it once. */
export function Expose() {
  return (
    <Scene from={E.from} to={E.to}>
      <Drift from={E.from} to={E.to} amount={0.02}>
      <Headline h={HEAD.expose} at={E.head} out={E.headOut} />
      <Refused />
      <ExposeCard />
      <Cursor
        p={[
          [1950, 1150],
          [1790, 1070],
          [1650, 930],
          [1594, 872],
        ]}
        at={32.65}
        dur={1.2}
        pressAt={PRESS}
        from={32.6}
        to={PRESS + 0.55}
      />
      </Drift>
    </Scene>
  );
}

/** The gateway refusing a write that nobody approved. */
function Refused() {
  const strike = useTransform(time, (t) => hq(clamp01((t - 29.05) / 0.4)));
  const mark = useTransform(time, (t) => hq(clamp01((t - 29.2) / 0.3)));
  const markScale = useTransform(time, (t) => lerp(1.3, 1, springs.pop(t - 29.2)));
  const ink = useTransform(time, [29.05, 29.4], [C.paper, C.silver]);
  return (
    <Enter at={28.2} out={E.headOut} dur={0.7} y={20} style={{ ...panelStyle, left: 900, top: 168, width: 900, height: 68 }}>
      <div style={{ position: "absolute", left: 24, top: 23, display: "flex", alignItems: "baseline", gap: 14 }}>
        <span style={{ font: font(600, 19, 1), color: C.silver }}>executor ›</span>
        <span style={{ position: "relative" }}>
          <motion.span style={{ font: font(400, 21, 1), color: ink }}>gmail.send without approval</motion.span>
          <motion.span style={{ position: "absolute", left: -4, right: -4, top: "52%", height: 2, background: C.fog, originX: 0, scaleX: strike }} />
        </span>
      </div>
      <motion.div style={{ position: "absolute", right: 14, top: 13, opacity: mark, scale: markScale, originX: 1 }}>
        <Mark tone="failed" size={0.9}>
          Refused by gateway
        </Mark>
      </motion.div>
    </Enter>
  );
}

function ExposeCard() {
  const rim = useTransform(time, [PRESS + 0.1, PRESS + 0.5], [C.safe, C.rim]);
  const flash = useTransform(time, (t) => (t < PRESS + 0.04 ? 0 : 0.2 * (1 - expoOut(clamp01((t - PRESS - 0.04) / 0.5)))));
  const approveBg = useTransform(time, [HOVER, HOVER + 0.15, PRESS + 0.12, PRESS + 0.4], [C.safe, C.safeLit, C.safeLit, C.safe]);
  const press = useTransform(time, (t) => {
    const d = t - PRESS;
    if (d < 0) return 1;
    if (d < 0.08) return lerp(1, 0.955, d / 0.08);
    return lerp(0.955, 1, springs.pop(d - 0.08));
  });
  const buttons = useTransform(time, (t) => 1 - cubicIn(clamp01((t - PRESS - 0.35) / 0.3)));
  return (
    <Enter at={29.7} out={E.headOut} dur={0.9} y={40} blur={6} style={{ position: "absolute", ...CARD }}>
      <motion.div style={{ ...panelStyle, inset: 0, borderColor: rim }}>
        <div style={{ position: "absolute", left: 26, top: 22, display: "flex", alignItems: "center", gap: 18 }}>
          <SwapMark at={PRESS + 0.1} a={["you", "Expose"]} b={["fixed", "Approved"]} anchor="left" />
          <Roll
            at={PRESS + 0.16}
            anchor="left"
            style={{ font: font(700, 23, 1.3), color: C.paper }}
            a={<span>2 actions wait for you</span>}
            b={<span>Approved · each runs exactly once</span>}
          />
        </div>
        <div style={{ position: "absolute", left: 0, right: 0, top: 88, height: 2, background: C.rim }} />
        <ActionRow at={30.25} top={108} n="1" text="billing · create invoice INV-0042 · $4,800.00" ink={C.silverHi} weight={400} />
        <ActionRow at={30.4} top={160} n="2" text="gmail · send message" ink={C.paper} weight={700} />
        <Enter at={30.55} dur={0.7} y={14} blur={3} style={{ position: "absolute", left: 26, right: 26, top: 212, height: 212, background: C.ground, border: `2px solid ${C.rim}`, borderRadius: 8, boxSizing: "border-box" }}>
          {PAYLOAD.map(([k, v], i) => (
            <Enter key={k} at={30.75 + i * 0.16} dur={0.5} x={-12} y={0} blur={0} style={{ position: "absolute", left: 22, right: 22, top: 22 + i * 44, display: "flex", alignItems: "baseline" }}>
              <span style={{ width: 130, font: font(400, 19, 1.2), color: C.silver }}>{k}</span>
              <span style={{ font: font(400, 21, 1.2), color: C.paper }}>{v}</span>
            </Enter>
          ))}
        </Enter>
        {GATEWAY.map(([label, value], i) => (
          <Enter key={label} at={31.45 + i * 0.18} dur={0.6} y={12} blur={2} style={{ position: "absolute", left: 26 + i * 290, top: 450 }}>
            <div style={{ font: font(700, 15, 1.2), letterSpacing: "0.16em", textTransform: "uppercase", color: C.silver }}>{label}</div>
            <div style={{ marginTop: 12, font: font(600, 20, 1.2), color: C.paper }}>{value}</div>
          </Enter>
        ))}
        <div style={{ position: "absolute", left: 0, right: 0, top: 560, height: 2, background: C.rim }} />
        <motion.div style={{ position: "absolute", right: 26, top: 584, display: "flex", gap: 14, opacity: buttons }}>
          <Enter at={31.9} dur={0.6} y={10} blur={0}>
            <div
              style={{
                width: 150,
                height: 68,
                border: `2px solid rgba(241,100,100,0.6)`,
                borderRadius: 8,
                boxSizing: "border-box",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                font: font(600, 20, 1),
                letterSpacing: "0.08em",
                color: C.fog,
              }}
            >
              REJECT
            </div>
          </Enter>
          <Enter at={32.0} dur={0.6} y={10} blur={0}>
            <motion.div
              style={{
                width: 330,
                height: 68,
                background: approveBg,
                scale: press,
                borderRadius: 8,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                font: font(700, 20, 1),
                letterSpacing: "0.08em",
                color: C.ground,
              }}
            >
              APPROVE · EXPOSE
            </motion.div>
          </Enter>
        </motion.div>
        <Develop at={PRESS + 0.75} dur={0.9} style={{ position: "absolute", left: 26, right: 26, top: 598, display: "flex", alignItems: "center", gap: 18 }}>
          <Mark tone="fixed">Executed</Mark>
          <span style={{ font: font(600, 22, 1.2), color: C.paper }}>Ran exactly once · 2 of 2 actions · reading back</span>
        </Develop>
        <motion.div style={{ position: "absolute", inset: 0, borderRadius: 12, background: C.safe, opacity: flash, pointerEvents: "none" }} />
      </motion.div>
    </Enter>
  );
}

function ActionRow({ at, top, n, text, ink, weight }) {
  return (
    <Enter at={at} dur={0.6} y={12} blur={3} style={{ position: "absolute", left: 26, right: 26, top, height: 44, display: "flex", alignItems: "center", gap: 16 }}>
      <span style={{ width: 22, font: font(700, 19, 1), color: C.silver }}>{n}</span>
      <span style={{ flex: 1, font: font(weight, 21, 1.2), color: ink }}>{text}</span>
      <Mark tone={n === "2" ? "running" : "plan"} size={0.78}>
        Write
      </Mark>
    </Enter>
  );
}
