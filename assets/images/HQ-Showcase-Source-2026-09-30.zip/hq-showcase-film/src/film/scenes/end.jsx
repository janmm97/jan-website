import { motion, useTransform } from "framer-motion";
import { time, CINEMA, DURATION } from "../time";
import { T } from "../timeline";
import { C } from "../colors";
import { END } from "../copy";
import { clamp01, lerp, camera } from "../ease";
import { Scene, Enter, Develop, StripBar, font } from "../prims";

/** End card: the wordmark develops again, then what it does and what it is built with. */
export function End() {
  const e = T.end;
  const scale = useTransform(time, (t) => (CINEMA ? lerp(1, 1.035, camera(clamp01((t - e.from) / (e.to - e.from)))) : 1));
  // The README cut keeps the light on and fades only the card, so the loop lands on the opening frame.
  const opacity = useTransform(time, (t) => (CINEMA ? 1 : 1 - clamp01((t - (DURATION - 1.1)) / 0.9)));
  return (
    <Scene from={e.from} to={e.to}>
      <motion.div style={{ position: "absolute", inset: 0, scale, opacity }}>
        <Develop at={54.45} dur={1.0} style={{ position: "absolute", left: 0, right: 0, top: 318, display: "flex", justifyContent: "center", alignItems: "baseline", gap: 26 }}>
          <span style={{ font: font(800, 172, 1), letterSpacing: "-0.045em", color: C.paper }}>J/OS</span>
          <span style={{ font: font(700, 52, 1), letterSpacing: "0.22em", color: C.silverHi }}>HQ</span>
        </Develop>
        <StripBar left={610} top={548} width={700} height={12} at={54.95} stagger={0.07} dur={0.5} />
        <Enter at={55.25} dur={0.8} y={18} style={{ position: "absolute", left: 0, right: 0, top: 606, textAlign: "center", font: font(500, 36, 1.2), color: C.silverHi }}>
          {END.steps.map((s, i) => (
            <span key={s}>
              {i > 0 && <span style={{ color: C.gray }}> · </span>}
              {s}
            </span>
          ))}
        </Enter>
        <Enter at={55.6} dur={0.8} y={16} style={{ position: "absolute", left: 0, right: 0, top: 690, textAlign: "center", font: font(400, 25, 1.3), color: C.silver }}>
          {END.built}
        </Enter>
        <Enter at={55.95} dur={0.8} y={14} style={{ position: "absolute", left: 0, right: 0, top: 758, textAlign: "center", font: font(600, 30, 1.2), color: C.paper }}>
          {END.url}
        </Enter>
      </motion.div>
    </Scene>
  );
}
