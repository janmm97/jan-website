import { motion, useTransform } from "framer-motion";
import { time } from "../time";
import { T } from "../timeline";
import { C } from "../colors";
import { HEAD, REQUEST, REQUEST_ENTITY, LADDER, WORKSPACES } from "../copy";
import { clamp01, lerp, hq, springs, cubicIn } from "../ease";
import { Scene, Drift, Headline, Enter, Label, Mark, SwapMark, panelStyle, font } from "../prims";

const R = T.route;
const ROUTED = 14.1; // the moment the request locks onto One

/** 02 Route: the request, the routing order read top-down, and the lock onto one workspace. */
export function Route() {
  return (
    <Scene from={R.from} to={R.to}>
      <Drift from={R.from} to={R.to} amount={0.012}>
      <Headline h={HEAD.route} at={R.head} out={R.headOut} />
      <RequestCard />
      <Ladder />
      {WORKSPACES.map((w, i) => (
        <Bay key={w.name} w={w} i={i} />
      ))}
      <RoutePath />
      <Enter at={15.1} out={R.headOut} dur={0.8} y={18} style={{ position: "absolute", left: 900, top: 852, width: 900 }}>
        <div
          style={{
            height: 78,
            boxSizing: "border-box",
            border: `2px dashed ${C.rimStrong}`,
            borderRadius: 12,
            display: "flex",
            alignItems: "center",
            gap: 18,
            padding: "0 26px",
            font: font(400, 21, 1.3),
            color: C.silverHi,
          }}
        >
          <span style={{ font: font(700, 17, 1), letterSpacing: "0.16em", color: C.silver }}>IF NOTHING SETTLES IT</span>
          <span>HQ asks which workspace. It never guesses.</span>
        </div>
      </Enter>
      </Drift>
    </Scene>
  );
}

/**
 * The request, lifted out of the composer. It starts scaled and placed so its text sits exactly on the
 * composer's (38px there, 30px here), then settles into the card on a soft spring.
 */
function RequestCard() {
  const a = T.ask;
  const s0 = 38 / 30;
  const k = (t) => springs.soft(t - (a.send + 0.12));
  const x = useTransform(time, (t) => lerp(38 - s0 * 28, 0, k(t)));
  const y = useTransform(time, (t) => lerp(260 - s0 * 90, 0, k(t)));
  const scale = useTransform(time, (t) => lerp(s0, 1, k(t)));
  const visible = useTransform(time, (t) => (t < a.send + 0.12 ? 0 : 1 - cubicIn(clamp01((t - R.headOut) / 0.45))));
  const chrome = useTransform(time, (t) => hq(clamp01((t - a.send - 0.35) / 0.6)));
  const underline = useTransform(time, (t) => hq(clamp01((t - 12.6) / 0.5)));
  return (
    <motion.div style={{ position: "absolute", left: 900, top: 168, width: 900, height: 204, x, y, scale, originX: 0, originY: 0, opacity: visible }}>
      <motion.div style={{ ...panelStyle, inset: 0, opacity: chrome }} />
      <motion.div style={{ position: "absolute", left: 28, right: 28, top: 26, display: "flex", alignItems: "center", justifyContent: "space-between", opacity: chrome }}>
        <Label>Request</Label>
        <SwapMark at={ROUTED + 0.15} a={["plan", "Routing"]} b={["running", "Route · One"]} />
      </motion.div>
      <div style={{ position: "absolute", left: 28, top: 90, font: font(400, 30, 1.45), color: C.paper, whiteSpace: "pre-wrap" }}>{REQUEST}</div>
      {/* 18px is one JetBrains Mono advance at 30px: the underline sits exactly under the entity's name. */}
      <motion.div
        style={{ position: "absolute", left: 28 + REQUEST.indexOf(REQUEST_ENTITY) * 18, top: 90 + 40, width: REQUEST_ENTITY.length * 18, height: 3, background: C.paper, originX: 0, scaleX: underline }}
      />
    </motion.div>
  );
}

function Ladder() {
  return (
    <Enter at={10.75} out={R.headOut} dur={0.8} y={30} style={{ ...panelStyle, left: 900, top: 396, width: 380, height: 430 }}>
      <Label style={{ position: "absolute", left: 24, top: 26 }}>Routing order</Label>
      {LADDER.map((r, i) => (
        <Rung key={r.n} r={r} i={i} />
      ))}
    </Enter>
  );
}

function Rung({ r, i }) {
  const top = 70 + i * 88;
  const on = i === 0 ? [12.0, 12.55] : i === 1 ? [12.55, 99] : null;
  const bg = useTransform(time, on ? [on[0], on[0] + 0.2, on[1], on[1] + 0.2] : [0, 1], on ? [C.clear, C.tray, C.tray, C.clear] : [C.clear, C.clear]);
  const ring = useTransform(time, (t) => (i === 1 ? hq(clamp01((t - 12.55) / 0.3)) : 0));
  const dim = useTransform(time, (t) => (i >= 2 ? lerp(1, 0.36, hq(clamp01((t - 13.1) / 0.5))) : 1));
  const foundAt = i === 0 ? 12.15 : i === 1 ? 12.7 : 13.15;
  const found = useTransform(time, (t) => hq(clamp01((t - foundAt) / 0.4)));
  const match = useTransform(time, (t) => (i === 1 ? hq(clamp01((t - 12.9) / 0.35)) : 0));
  const matchScale = useTransform(time, (t) => lerp(1.3, 1, springs.pop(t - 12.9)));
  return (
    <motion.div style={{ position: "absolute", left: 10, right: 10, top, height: 80, borderRadius: 8, background: bg, opacity: dim }}>
      <motion.div style={{ position: "absolute", inset: 0, borderRadius: 8, boxShadow: `inset 0 0 0 2px ${C.paper}`, opacity: ring }} />
      <div style={{ position: "absolute", left: 16, top: 14, font: font(700, 20, 1), color: C.silver }}>{r.n}</div>
      <div style={{ position: "absolute", left: 50, top: 12, font: font(600, 21, 1.2), color: C.paper }}>{r.rule}</div>
      <motion.div style={{ position: "absolute", left: 50, top: 44, font: font(i === 1 ? 700 : 400, 18, 1.2), color: i === 1 ? C.paper : C.silver, opacity: found }}>
        {r.found}
      </motion.div>
      <motion.div style={{ position: "absolute", right: 14, top: 38, opacity: match, scale: matchScale, originX: 1 }}>
        <Mark tone="running" size={0.82}>
          Match
        </Mark>
      </motion.div>
    </motion.div>
  );
}

function Bay({ w, i }) {
  const top = i === 0 ? 396 : 621;
  const lit = useTransform(time, [ROUTED, ROUTED + 0.3], [C.rim, C.paper]);
  const dim = useTransform(time, (t) => (i === 1 ? lerp(1, 0.4, hq(clamp01((t - ROUTED) / 0.5))) : 1));
  return (
    <Enter at={11.0 + i * 0.14} out={R.headOut} dur={0.8} x={30} y={0} style={{ position: "absolute", left: 1420, top, width: 380, height: 205 }}>
      <motion.div style={{ ...panelStyle, inset: 0, borderColor: i === 0 ? lit : C.rim, opacity: dim }}>
        <div style={{ position: "absolute", left: 24, top: 24, font: font(700, 30, 1), color: C.paper }}>{w.name}</div>
        <div style={{ position: "absolute", left: 24, top: 74, font: font(600, 19, 1.2), color: C.silverHi }}>{w.harness}</div>
        <div style={{ position: "absolute", left: 24, top: 104, font: font(400, 17, 1.2), color: C.silver }}>{w.model}</div>
        <div style={{ position: "absolute", left: 24, bottom: 22 }}>
          {i === 0 ? <SwapMark at={ROUTED} a={["plan", "Bay free"]} b={["running", "Routed here"]} size={0.9} anchor="left" /> : <Mark tone="plan" size={0.9}>Bay free</Mark>}
        </div>
      </motion.div>
    </Enter>
  );
}

function RoutePath() {
  const pathLength = useTransform(time, (t) => hq(clamp01((t - 13.3) / 0.75)));
  const start = useTransform(time, (t) => hq(clamp01((t - 13.25) / 0.2)) * (1 - cubicIn(clamp01((t - R.headOut) / 0.4))));
  const end = useTransform(time, (t) => hq(clamp01((t - 14.0) / 0.2)) * (1 - cubicIn(clamp01((t - R.headOut) / 0.4))));
  const endR = useTransform(time, (t) => 7 * lerp(2.2, 1, springs.pop(t - 14.0)));
  return (
    <svg width="1920" height="1080" style={{ position: "absolute", inset: 0, overflow: "visible", pointerEvents: "none" }}>
      <motion.path d="M1280 598 C 1352 598, 1348 498, 1420 498" fill="none" stroke={C.paper} strokeWidth="3" style={{ pathLength, opacity: start }} />
      <motion.circle cx="1280" cy="598" r="6" fill={C.paper} style={{ opacity: start }} />
      <motion.circle cx="1420" cy="498" r={endR} fill={C.paper} style={{ opacity: end }} />
    </svg>
  );
}
