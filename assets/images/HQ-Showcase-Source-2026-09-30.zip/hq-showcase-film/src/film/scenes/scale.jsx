import { motion, useTransform } from "framer-motion";
import { time } from "../time";
import { T } from "../timeline";
import { C } from "../colors";
import { HEAD, GLANCE, BAYS, WORKSPACES, DRYING, AGENTS, FLOW } from "../copy";
import { clamp01, hq } from "../ease";
import { Scene, Headline, Enter, Drift, Label, Mark, Ring, Elapsed, panelStyle, font } from "../prims";

const S = T.scale;
const SWAP = 50.7; // the lower row turns from the drying line and an agent to a One Flow

/** 06 Scale: the whole bench at once: the glance band, a line per workspace, agents and a flow. */
export function Scale() {
  return (
    <Scene from={S.from} to={S.to}>
      <Drift from={S.from} to={S.to} amount={0.018}>
        <Headline h={HEAD.scale} at={S.head} />
        <Enter at={46.6} dur={0.85} y={30} style={{ ...panelStyle, left: 900, top: 150, width: 900, height: 256 }}>
          <Label style={{ position: "absolute", left: 26, top: 24 }}>At a glance · today</Label>
          <div style={{ position: "absolute", left: 26, right: 26, top: 70, display: "flex", justifyContent: "space-around" }}>
            {GLANCE.map((g, i) => (
              <Ring key={g.label} at={46.95 + i * 0.12} value={g.value} of={g.of} label={g.label} size={118} tone={[C.fixed, C.silverHi, C.fog, C.paper][i]} />
            ))}
          </div>
        </Enter>
        {BAYS.map((b, i) => (
          <Bay key={b.name} b={b} i={i} />
        ))}
        <Enter at={48.3} out={SWAP} dur={0.8} y={26} style={{ ...panelStyle, left: 900, top: 666, width: 440, height: 264 }}>
          <Label style={{ position: "absolute", left: 22, top: 22 }}>Drying line</Label>
          {DRYING.map(([at, title], i) => (
            <Enter key={title} at={48.55 + i * 0.18} dur={0.55} x={-12} y={0} blur={2} style={{ position: "absolute", left: 22, right: 18, top: 70 + i * 62, display: "flex", alignItems: "center", gap: 14 }}>
              <span style={{ font: font(400, 16, 1), color: C.silver }}>{at}</span>
              <span style={{ flex: 1, minWidth: 0, font: font(400, 17, 1.2), color: C.paper, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{title}</span>
              <Mark tone="fixed" size={0.7}>
                Verified
              </Mark>
            </Enter>
          ))}
        </Enter>
        <AgentCard />
        <FlowCard />
      </Drift>
    </Scene>
  );
}

function Bay({ b, i }) {
  const w = WORKSPACES[i];
  return (
    <Enter at={47.35 + i * 0.12} dur={0.8} y={26} style={{ ...panelStyle, left: 900 + i * 460, top: 426, width: 440, height: 220 }}>
      <div style={{ position: "absolute", left: 22, top: 22, font: font(700, 26, 1), color: C.paper }}>{b.name}</div>
      <div style={{ position: "absolute", right: 22, top: 26, font: font(400, 16, 1), color: C.silver }}>{w.harness}</div>
      <div style={{ position: "absolute", left: 22, right: 22, top: 66, display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <Mark tone="running" size={0.8}>
          Running
        </Mark>
        <Elapsed base={b.elapsed} at={47.4} style={{ font: font(200, 30, 1), color: C.paper }} />
      </div>
      <div style={{ position: "absolute", left: 22, right: 22, top: 118, font: font(600, 19, 1.2), color: C.paper, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{b.running}</div>
      <div
        style={{
          position: "absolute",
          left: 22,
          right: 22,
          top: 158,
          height: 42,
          border: `2px dashed ${C.silver}`,
          borderRadius: 6,
          boxSizing: "border-box",
          display: "flex",
          alignItems: "center",
          gap: 12,
          padding: "0 14px",
          font: font(400, 16, 1),
          color: C.silverHi,
        }}
      >
        <span style={{ font: font(700, 13, 1), letterSpacing: "0.12em", color: C.silver }}>IN LINE</span>
        <span style={{ whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
          {b.line[0]}
          {b.line.length > 1 ? `  +${b.line.length - 1}` : ""}
        </span>
      </div>
    </Enter>
  );
}

function AgentCard() {
  const a = AGENTS[0];
  const rows = [
    ["gmail · read", "may", C.silverHi],
    ["gmail · draft", "may", C.silverHi],
    ["gmail · send", "never", C.silver],
    ["billing · any", "refused", C.fog],
  ];
  return (
    <Enter at={48.5} out={SWAP} dur={0.8} y={26} style={{ ...panelStyle, left: 1360, top: 666, width: 440, height: 264 }}>
      <div style={{ position: "absolute", left: 22, top: 22, font: font(700, 21, 1), color: C.paper }}>{a.name}</div>
      <div style={{ position: "absolute", left: 22, top: 54, font: font(400, 15, 1.2), color: C.silver }}>sub-agent · scope enforced in code</div>
      {rows.map(([what, verdict, ink], i) => (
        <Enter key={what} at={48.75 + i * 0.16} dur={0.5} x={-10} y={0} blur={2} style={{ position: "absolute", left: 22, right: 22, top: 98 + i * 40, display: "flex", alignItems: "baseline", justifyContent: "space-between" }}>
          <span style={{ font: font(400, 17, 1.2), color: C.paper }}>{what}</span>
          <span style={{ font: font(700, 14, 1.2), letterSpacing: "0.14em", textTransform: "uppercase", color: ink }}>{verdict}</span>
        </Enter>
      ))}
    </Enter>
  );
}

const NODE_W = 104;
const COL = (c) => 26 + c * 146;
const NODES = [
  { id: "trigger", c: 0, y: 140 },
  { id: "paginate", c: 1, y: 140 },
  { id: "transform", c: 2, y: 140 },
  { id: "condition", c: 3, y: 140 },
  { id: "send", c: 4, y: 94 },
  { id: "skip", c: 4, y: 186 },
  { id: "verify", c: 5, y: 140 },
];
const EDGES = [
  ["trigger", "paginate"],
  ["paginate", "transform"],
  ["transform", "condition"],
  ["condition", "send"],
  ["condition", "skip"],
  ["send", "verify"],
  ["skip", "verify"],
];
const FLOW_IN = SWAP + 0.42; // after the drying line and the agent card have gone
const nodeAt = (c) => FLOW_IN + 0.2 + c * 0.16;

/** A One Flow drawn as the dependency graph it is. */
function FlowCard() {
  const byId = Object.fromEntries(NODES.map((n) => [n.id, n]));
  return (
    <Enter at={FLOW_IN} dur={0.8} y={26} style={{ ...panelStyle, left: 900, top: 666, width: 900, height: 264 }}>
      <Label style={{ position: "absolute", left: 26, top: 24 }}>One Flow · {FLOW.key}</Label>
      <Enter at={FLOW_IN + 1.45} dur={0.6} y={0} x={12} blur={0} style={{ position: "absolute", right: 26, top: 24, font: font(600, 17, 1.1), color: C.silverHi }}>
        {FLOW.status}
      </Enter>
      <svg width="896" height="260" style={{ position: "absolute", left: 0, top: 0, overflow: "visible" }}>
        {EDGES.map(([a, b]) => (
          <Edge key={a + b} from={byId[a]} to={byId[b]} />
        ))}
      </svg>
      {NODES.map((n) => (
        <Enter key={n.id} at={nodeAt(n.c)} dur={0.5} y={0} scale={0.86} blur={3} style={{ position: "absolute", left: COL(n.c), top: n.y, width: NODE_W, height: 50 }}>
          <div
            style={{
              width: "100%",
              height: "100%",
              boxSizing: "border-box",
              border: `2px solid ${n.id === "send" ? C.paper : C.rimStrong}`,
              borderRadius: 6,
              background: C.tray,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              font: font(600, 16, 1),
              color: C.paper,
            }}
          >
            {n.id}
          </div>
        </Enter>
      ))}
    </Enter>
  );
}

function Edge({ from, to }) {
  const x1 = COL(from.c) + NODE_W;
  const y1 = from.y + 25;
  const x2 = COL(to.c);
  const y2 = to.y + 25;
  const mx = (x1 + x2) / 2;
  const at = nodeAt(from.c) + 0.2;
  const pathLength = useTransform(time, (t) => hq(clamp01((t - at) / 0.35)));
  const opacity = useTransform(time, (t) => (t > at ? 1 : 0));
  return <motion.path d={`M${x1} ${y1} C ${mx} ${y1}, ${mx} ${y2}, ${x2} ${y2}`} fill="none" stroke={C.silver} strokeWidth="2" style={{ pathLength, opacity }} />;
}
