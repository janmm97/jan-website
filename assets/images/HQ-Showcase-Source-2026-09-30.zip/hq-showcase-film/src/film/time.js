import { motionValue } from "framer-motion";

// One master clock drives every property in the film. Nothing animates on its own: each value is a
// pure function of `time`, so any frame can be rendered exactly, in any order, by setting the clock.
export const time = motionValue(0);
export const FPS = 50;
export const DURATION = 59;
// ?gif renders the README cut: no whole-frame camera drift, so an animated image only stores what moves.
export const CINEMA = typeof location === "undefined" || !new URLSearchParams(location.search).has("gif");
