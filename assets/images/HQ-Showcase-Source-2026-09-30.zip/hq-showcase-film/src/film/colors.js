// HQ's DESIGN.md palette as literal hex, for values that interpolate over time.
export const C = {
  ground: "#0b0b0b",
  room: "#121212",
  tray: "#1a1a1a",
  rim: "#2a2a2a",
  rimStrong: "#4a4a4a",
  gray: "#6a6a6a",
  silver: "#9a9a9a",
  silverHi: "#c4c4c4",
  fixed: "#d9d9d9",
  paper: "#f2f2f2",
  safe: "#ffb000",
  safeLit: "#ffc233",
  fog: "#f16464",
  strip: ["#f2f2f2", "#c4c4c4", "#8a8a8a", "#3a3a3a", "#222222", "#141414"],
  clear: "rgba(26,26,26,0)",
};
