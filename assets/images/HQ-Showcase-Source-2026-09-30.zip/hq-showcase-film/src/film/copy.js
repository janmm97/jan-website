// Every word that appears on screen, in one place so it can be audited for leaks.
// All people, companies, emails and IDs here are invented stand-ins.

export const TAGLINE = ["AI agents that act on your real systems.", ["Nothing leaves without ", "your approval."]];

export const CHAPTERS = ["Ask", "Route", "Plan", "Expose", "Verify", "Scale"];

export const HEAD = {
  ask: { code: "01", label: "Ask", title: ["One request."], sub: "Type it once, in plain language. J/OS HQ works out the rest." },
  route: {
    code: "02",
    label: "Route",
    title: ["The right", "workspace."],
    sub: "An explicit choice first, then named people and flows, then who holds the live connection. Still unsure? It asks.",
  },
  plan: {
    code: "03",
    label: "Plan",
    title: ["Plans read-only,", "checks for real."],
    sub: "A planning session reads every action's docs. HQ checks each step against the live environment.",
  },
  expose: {
    code: "04",
    label: "Expose",
    title: ["You approve the", "exact payload."],
    sub: "The gateway dry-runs every write and runs the approved payload exactly once. Anything unapproved is refused, in code.",
  },
  verify: {
    code: "05",
    label: "Verify",
    title: ["Proof, not", "a 200 OK."],
    sub: "Tool success isn't the goal. HQ reads the outcome back, then logs the task twice.",
  },
  scale: {
    code: "06",
    label: "Scale",
    title: ["Run it all from", "one bench."],
    sub: "A line per workspace, sub-agents with scope enforced in code, and every workflow a One Flow.",
  },
};

export const REQUEST = "Send Contoso the signed proposal\nand invoice the 40% deposit.";
export const REQUEST_ENTITY = "Contoso";

export const WORKSPACES = [
  { name: "One", harness: "Claude Code", model: "Opus 5.5 · medium" },
  { name: "Studio", harness: "Codex CLI", model: "GPT 6 Sol · medium" },
];

export const LADDER = [
  { n: "1", rule: "Explicit choice", found: "none given" },
  { n: "2", rule: "Named entity · flow", found: "“Contoso”" },
  { n: "3", rule: "Connection owner", found: "not needed" },
  { n: "4", rule: "Still unsure", found: "ask, never guess" },
];

export const PLAN_STREAM = [
  ["one --agent connection list", "4 live"],
  ['one --agent actions search drive "find file"', "3 found"],
  ["one --agent actions knowledge drive …", "read"],
  ["one --agent actions knowledge gmail …", "read"],
];

export const PLAN_STEPS = [
  { kind: "READ", text: "drive · find the signed proposal", check: "ok" },
  { kind: "READ", text: "drive · export proposal.pdf", check: "flag" },
  { kind: "WRITE", text: "billing · create INV-0042 · 40%", check: "ok" },
  { kind: "WRITE", text: "gmail · send to Contoso", check: "ok" },
];

export const PAYLOAD = [
  ["to", "Contoso <accounts@example.com>"],
  ["subject", "Signed proposal + deposit invoice"],
  ["attach", "proposal-signed.pdf · INV-0042.pdf"],
  ["body", "Attached are the signed proposal and…"],
];

export const GATEWAY = [
  ["HQ dry-run", "✓ matches"],
  ["Payload hash", "sha-256 9f3c…a41e"],
  ["Runs", "exactly once"],
];

export const STATIONS = [
  { name: "Compose", role: "route · plan" },
  { name: "Test strip", role: "dry-run" },
  { name: "Expose", role: "approved" },
  { name: "Develop", role: "ran once" },
  { name: "Fix", role: "read back" },
  { name: "Dry", role: "logged" },
];

export const RESULT = {
  title: "Sent Contoso the signed proposal",
  rows: [
    ["gmail", "message 18c2f0a94e71", "read back"],
    ["billing", "INV-0042 · open · $4,800.00", "read back"],
  ],
  took: "Took 1:24 · $0.21",
};

export const LOG_LINES = [
  "## 2026-09-30 · Send Contoso the signed proposal",
  "- Status: done · verified",
  "- Route: One · named entity “Contoso”",
];

export const GLANCE = [
  { label: "Completed", value: 26, of: 35 },
  { label: "In line", value: 3, of: 9 },
  { label: "Failed", value: 1, of: 35 },
  { label: "Agents", value: 7, of: 7 },
];

export const BAYS = [
  { name: "One", running: "Weekly metrics digest", elapsed: 134, line: ["Draft onboarding email", "Summarize support inbox"] },
  { name: "Studio", running: "Reconcile September invoices", elapsed: 48, line: ["Publish release notes"] },
];

export const DRYING = [
  ["09:42", "Proposal to Contoso", "$0.21"],
  ["09:18", "Meeting-notes flow", "$0.08"],
  ["08:55", "Pricing sheet refresh", "$0.05"],
];

export const AGENTS = [
  { name: "one_inbox_scout", scope: "gmail · read, draft" },
  { name: "studio_ledger_clerk", scope: "billing · read" },
];

export const FLOW = {
  key: "weekly-digest",
  nodes: ["trigger", "paginate", "transform", "condition", "send", "verify"],
  status: "validated · dry-run ✓",
};

export const END = {
  steps: ["Route", "Plan", "Expose", "Verify"],
  built: "Built with Claude Code by Anthropic · Codex CLI by OpenAI · One",
  url: "github.com/janmm97/janhq",
};
