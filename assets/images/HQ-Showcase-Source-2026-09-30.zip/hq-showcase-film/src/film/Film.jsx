import { T } from "./timeline";
import { Light, Chrome, FadeOut } from "./chrome";
import { StripWipe } from "./prims";
import { Open } from "./scenes/open";
import { Ask } from "./scenes/ask";
import { Route } from "./scenes/route";
import { Plan } from "./scenes/plan";
import { Expose } from "./scenes/expose";
import { Verify } from "./scenes/verify";
import { Scale } from "./scenes/scale";
import { End } from "./scenes/end";

/** The whole film on one 1920×1080 stage. Layers, back to front: light, scenes, chrome, cuts, fade. */
export function Film() {
  return (
    <div id="stage">
      <Light />
      <Open />
      <Ask />
      <Route />
      <Plan />
      <Expose />
      <Verify />
      <Scale />
      <End />
      <Chrome />
      <StripWipe at={T.wipe1} />
      <StripWipe at={T.wipe2} />
      <FadeOut />
    </div>
  );
}
