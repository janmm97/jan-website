import { spring, cubicBezier } from "framer-motion";

export const clamp01 = (v) => (v < 0 ? 0 : v > 1 ? 1 : v);
export const lerp = (a, b, p) => a + (b - a) * p;
export const seg = (t, a, b, ease = (x) => x) => ease(clamp01((t - a) / (b - a)));

export const linear = (t) => t;
export const expoOut = (t) => (t >= 1 ? 1 : 1 - Math.pow(2, -10 * t));
export const expoIn = (t) => (t <= 0 ? 0 : Math.pow(2, 10 * t - 10));
export const expoInOut = (t) =>
  t <= 0 ? 0 : t >= 1 ? 1 : t < 0.5 ? Math.pow(2, 20 * t - 10) / 2 : (2 - Math.pow(2, -20 * t + 10)) / 2;
export const cubicIn = (t) => t * t * t;
export const cubicOut = (t) => 1 - Math.pow(1 - t, 3);
export const cubicInOut = (t) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2);
export const quintOut = (t) => 1 - Math.pow(1 - t, 5);
export const sineInOut = (t) => -(Math.cos(Math.PI * t) - 1) / 2;
// HQ's own transition curve (DESIGN.md: 200 ms ease-out-expo), and a slower camera curve.
export const hq = cubicBezier(0.16, 1, 0.3, 1);
export const camera = cubicBezier(0.65, 0, 0.35, 1);

/** Motion's spring, sampled once into a table so a frame's value never depends on frame order. */
function springTable(opts) {
  const g = spring({ keyframes: [0, 1], ...opts });
  const N = 4000;
  const table = new Float32Array(N + 1);
  for (let i = 0; i <= N; i++) table[i] = g.next(i).value;
  return (dt) => (dt <= 0 ? 0 : dt * 1000 >= N ? 1 : table[Math.round(dt * 1000)]);
}
export const springs = {
  pop: springTable({ stiffness: 320, damping: 22, mass: 1 }),
  soft: springTable({ stiffness: 150, damping: 24, mass: 1 }),
  snap: springTable({ stiffness: 520, damping: 36, mass: 1 }),
  settle: springTable({ stiffness: 90, damping: 18, mass: 1.1 }),
};

/** Seeded PRNG (mulberry32): typing rhythm that is irregular but identical on every render. */
export function prng(seed) {
  let s = seed >>> 0;
  return () => {
    s = (s + 0x6d2b79f5) >>> 0;
    let t = Math.imul(s ^ (s >>> 15), 1 | s);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/** Per-character timestamps for a typed line; the last entry is when typing ends. */
export function typeTimes(text, at, cps = 26, seed = 7) {
  const r = prng(seed);
  const times = [];
  let acc = at;
  for (const ch of text) {
    times.push(acc);
    acc += (1 / cps) * (0.55 + r() * 0.9) + (/[,.]/.test(ch) ? 0.16 : 0) + (ch === " " ? 0.015 : 0);
  }
  times.push(acc);
  return times;
}
