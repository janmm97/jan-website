import { motion, useTransform } from "framer-motion";
import { time, DURATION, CINEMA } from "./time";
import { T } from "./timeline";
import { C } from "./colors";
import { CHAPTERS } from "./copy";
import { clamp01, hq, cubicIn } from "./ease";
import { Scene, font } from "./prims";

/** The enlarger light: a neutral pool at the head of the frame. */
export function Light() {
  // In the README cut the light stays on: a whole-frame fade is the most expensive thing a GIF can store.
  const opacity = useTransform(time, (t) => (CINEMA ? hq(clamp01((t - 0.15) / 2.2)) * (1 - clamp01((t - (DURATION - 1)) / 1)) : 1));
  return (
    <motion.div
      style={{
        position: "absolute",
        inset: 0,
        opacity,
        background: "radial-gradient(ellipse 1500px 760px at 50% -10%, #1e1e1e 0%, #171717 40%, rgba(11,11,11,0) 86%)",
      }}
    />
  );
}

/** The last second: everything settles back to the ground, so the loop restarts on black. */
export function FadeOut() {
  const opacity = useTransform(time, (t) => (CINEMA ? cubicIn(clamp01((t - (DURATION - 1)) / 0.95)) : 0));
  return <motion.div style={{ position: "absolute", inset: 0, background: C.ground, opacity, zIndex: 60 }} />;
}

/** HQ's frame around the story: the wordmark, the runtime pins, the Needs-you chip and the chapters. */
export function Chrome() {
  const { from, to, needsFrom, needsTo } = T.chrome;
  return (
    <Scene from={from} to={to} style={{ zIndex: 30, pointerEvents: "none" }}>
      <div style={{ position: "absolute", left: 120, top: 62, display: "flex", alignItems: "baseline", gap: 12 }}>
        <span style={{ font: font(800, 34, 1), letterSpacing: "-0.02em", color: C.paper }}>J/OS</span>
        <span style={{ font: font(700, 15, 1), letterSpacing: "0.18em", color: C.silverHi }}>HQ</span>
      </div>
      <NeedsYou from={needsFrom} to={needsTo} />
      <div
        style={{
          position: "absolute",
          right: 120,
          top: 50,
          height: 56,
          display: "flex",
          alignItems: "center",
          gap: 14,
          padding: "0 20px",
          border: `2px solid ${C.rim}`,
          borderRadius: 8,
          boxSizing: "border-box",
        }}
      >
        <span style={{ font: font(700, 15, 1), letterSpacing: "0.16em", color: C.silver }}>RUNTIME</span>
        <span style={{ width: 9, height: 9, background: C.fixed, borderRadius: 1 }} />
        <span style={{ font: font(600, 18, 1), color: C.paper }}>4 pins verified</span>
      </div>
      <ChapterStrip />
    </Scene>
  );
}

function NeedsYou({ from, to }) {
  const opacity = useTransform(time, (t) => hq(clamp01((t - from) / 0.35)) * (1 - clamp01((t - to) / 0.25)));
  const x = useTransform(time, (t) => (1 - hq(clamp01((t - from) / 0.5))) * 24);
  return (
    <motion.div
      style={{
        position: "absolute",
        right: 462,
        top: 50,
        height: 56,
        display: "flex",
        alignItems: "center",
        gap: 12,
        padding: "0 20px",
        background: C.safe,
        borderRadius: 8,
        opacity,
        x,
      }}
    >
      <span style={{ width: 10, height: 10, background: C.ground, borderRadius: 1 }} />
      <span style={{ font: font(700, 17, 1), letterSpacing: "0.1em", color: C.ground }}>NEEDS YOU · 1</span>
    </motion.div>
  );
}

/** The six chapters as a test strip: done chapters take their step, the current one is ringed. */
function ChapterStrip() {
  const W = 180;
  return (
    <div style={{ position: "absolute", left: (1920 - W * 6) / 2, top: 990, width: W * 6, height: 46, display: "flex", borderRadius: 4, overflow: "hidden" }}>
      {CHAPTERS.map((name, i) => (
        <Chapter key={name} i={i} name={name} w={W} />
      ))}
    </div>
  );
}

function Chapter({ i, name, w }) {
  const s = T.chapters[i];
  const n = T.chapters[i + 1] ?? T.chaptersEnd;
  const done = C.strip[i];
  const doneInk = i < 3 ? C.ground : C.silverHi;
  const background = useTransform(time, [s - 0.01, s + 0.3, n, n + 0.35], [C.clear, C.tray, C.tray, done]);
  const color = useTransform(time, [s - 0.01, s + 0.3, n, n + 0.35], [C.gray, C.paper, C.paper, doneInk]);
  const ring = useTransform(time, (t) => clamp01((t - s) / 0.3) * (1 - clamp01((t - n) / 0.3)));
  const dash = useTransform(time, (t) => 1 - clamp01((t - s) / 0.3));
  return (
    <motion.div style={{ position: "relative", width: w, height: "100%", background, color, display: "flex", alignItems: "center", justifyContent: "center" }}>
      <motion.div style={{ position: "absolute", inset: 0, border: `2px dashed ${C.rimStrong}`, borderLeftWidth: i === 0 ? 2 : 0, opacity: dash }} />
      <motion.div style={{ position: "absolute", inset: 0, boxShadow: `inset 0 0 0 2px ${C.paper}`, opacity: ring }} />
      <span style={{ position: "relative", font: font(800, 15, 1), letterSpacing: "0.12em", textTransform: "uppercase" }}>{name}</span>
    </motion.div>
  );
}
