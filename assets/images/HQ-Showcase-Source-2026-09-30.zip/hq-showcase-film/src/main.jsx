import "@fontsource-variable/jetbrains-mono";
import "./theme.css";
import { createRoot } from "react-dom/client";
import { Film } from "./film/Film";
import { time, FPS, DURATION } from "./film/time";

createRoot(document.getElementById("root")).render(<Film />);

const nextFrame = () => new Promise((r) => requestAnimationFrame(() => r()));

// The renderer's handle: set the clock, then wait until Motion has written every style to the DOM.
window.__film = {
  fps: FPS,
  duration: DURATION,
  ready: document.fonts.ready.then(nextFrame).then(nextFrame),
  async seek(t) {
    time.set(t);
    await nextFrame();
    await nextFrame();
  },
};

// Preview in a browser: ?t=12.5 holds a moment; ?play runs the film in real time, looping.
const q = new URLSearchParams(location.search);
if (q.has("t")) time.set(Number(q.get("t")));
if (q.has("play")) {
  const t0 = performance.now() - Number(q.get("play") || 0) * 1000;
  const tick = (now) => {
    time.set(((now - t0) / 1000) % DURATION);
    requestAnimationFrame(tick);
  };
  requestAnimationFrame(tick);
}
