// node contact.mjs out.png a.png b.png …  → a 3-column contact sheet of 640×360 thumbnails.
import { execFileSync } from "node:child_process";

const [out, ...files] = process.argv.slice(2);
const cols = 3;
const w = 640;
const h = 360;
const inputs = files.flatMap((f) => ["-i", f]);
const scaled = files.map((_, i) => `[${i}:v]scale=${w}:${h}:flags=lanczos[v${i}]`).join(";");
const layout = files.map((_, i) => `${(i % cols) * w}_${Math.floor(i / cols) * h}`).join("|");
const graph = files.length > 1 ? `${scaled};${files.map((_, i) => `[v${i}]`).join("")}xstack=inputs=${files.length}:layout=${layout}:fill=black` : scaled.replace("[v0]", "");
execFileSync("ffmpeg", ["-hide_banner", "-loglevel", "error", "-y", ...inputs, "-filter_complex", graph, "-frames:v", "1", out], { stdio: "inherit" });
console.log("wrote", out);
