# J/OS HQ showcase film — how to re-render

A 59-second motion graphic built with React and Framer Motion. Every property on screen is a pure
function of one clock (`src/film/time.js`), so any frame renders exactly, in any order.

- All on-screen words live in `src/film/copy.js`. Every name, company, email and ID there is
  invented. Before re-rendering after a copy change, run each source file through the export's
  leak check (`node jos-hq/scripts/export-public.mjs --check-text <file>`; files under 64 KB).
- Do not reuse the export's stand-in names (Northwind, Acme, Riley, …) as fiction: in the public
  code they stand for real accounts. The film's customer is "Contoso".
- The cue sheet is `src/film/timeline.js`; scenes are in `src/film/scenes/`.

## Preview

```
npm install
npm run dev            # http://localhost:5199/?play  (real time)  or  /?t=34.4  (one moment)
node shots.mjs 12.9 34.4          # stills into shots/
```

## Render

```
node render.mjs                   # out/master-cinema.mkv  1920x1080, 50 fps, camera drift on
node render.mjs --gif             # out/master-gif.mkv     25 fps, no drift/shadows/blur (README cut)
```

## Encode (the settings used on 2026-09-30)

MP4 for sharing:

```
ffmpeg -i out/master-cinema.mkv -vf "scale=in_range=full:out_range=tv:out_color_matrix=bt709:flags=lanczos+accurate_rnd+full_chroma_int,format=yuv420p" -c:v libx264 -preset slow -crf 14 -tune animation -profile:v high -level 4.2 -colorspace bt709 -color_primaries bt709 -color_trc bt709 -color_range tv -movflags +faststart -r 50 hq-showcase.mp4
```

README GIF (GitHub will not play a repo-hosted video; lossy WebP ghosts in dark areas, so GIF):

```
ffmpeg -i out/master-gif.mkv -vf "scale=1280:-1:flags=lanczos,split[a][b];[a]palettegen=max_colors=256:stats_mode=full[p];[b][p]paletteuse=dither=none:diff_mode=rectangle" -loop 0 jos-hq-ai-agent-command-center.gif
```

The GIF is published from `jos-hq/scripts/public/docs/`. Its bytes need a `reviewedBinaries` pin in
`jos-hq/export.private.json` (the export prints the exact entry): compressed pixel data spells short
names by chance, and the pin records that the frames were reviewed.
