// node shots.mjs 1.5 7.2 13.9 …  → shots/t<time>.png, one still per moment, for review.
import fs from "node:fs";
import { createServer } from "vite";
import { chromium } from "playwright-core";

const times = process.argv.slice(2).map(Number);
const server = await createServer({ server: { port: 5199, strictPort: true }, logLevel: "error" });
await server.listen();
const browser = await chromium.launch();
const page = await browser.newPage({ viewport: { width: 1920, height: 1080 }, deviceScaleFactor: 1 });
page.on("console", (m) => m.type() === "error" && console.error("page:", m.text()));
page.on("pageerror", (e) => console.error("pageerror:", e.message));
await page.goto("http://localhost:5199/");
await page.waitForFunction(() => window.__film);
await page.evaluate(() => window.__film.ready);
fs.mkdirSync("shots", { recursive: true });
for (const t of times) {
  await page.evaluate((x) => window.__film.seek(x), t);
  await page.screenshot({ path: `shots/t${t.toFixed(2)}.png` });
  console.log("shot", t);
}
await browser.close();
await server.close();
